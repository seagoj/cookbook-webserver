name              "apt"
description       "Updates apt"
version           "0.1"

recipe "apt", "Updates apt and prepares for installation"