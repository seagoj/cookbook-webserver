name              "nginx"
description       "Installs and configures nginx"
version           "0.1"

recipe "nginx", "Installs nginx package and sets up configuration"