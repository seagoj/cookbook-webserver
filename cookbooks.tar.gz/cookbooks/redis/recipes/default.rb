package 'redis-server'

