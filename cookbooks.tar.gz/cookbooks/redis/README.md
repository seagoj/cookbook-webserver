cookbook-redis
==============

Cookbook for installing redis