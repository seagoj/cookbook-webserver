## v1.1.2:

* [COOK-1424] - prevent plugin_path growth to infinity

## v1.1.0:

* [COOK-1174] - custom_plugins is only conditionally available
* [COOK-1383] - allow plugins from other cookbooks

## v1.0.2

- [COOK-463] ohai cookbook default recipe should only reload plugins if there were updates
